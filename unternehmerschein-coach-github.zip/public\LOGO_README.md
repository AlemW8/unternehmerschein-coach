# FahrGewerbe Logo
# Bitte das angehängte FahrGewerbe.png Logo in diesen Ordner kopieren
# Das Logo sollte als /public/FahrGewerbe.png gespeichert werden
