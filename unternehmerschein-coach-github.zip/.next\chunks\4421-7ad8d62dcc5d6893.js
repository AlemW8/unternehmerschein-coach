(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[4421],{2898:function(e,t,n){"use strict";n.d(t,{Z:function(){return i}});var r=n(2265),a={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),i=(e,t)=>{let n=(0,r.forwardRef)(({color:n="currentColor",size:i=24,strokeWidth:s=2,absoluteStrokeWidth:o,className:c="",children:u,...d},m)=>(0,r.createElement)("svg",{ref:m,...a,width:i,height:i,stroke:n,strokeWidth:o?24*Number(s)/Number(i):s,className:["lucide",`lucide-${l(e)}`,c].join(" "),...d},[...t.map(([e,t])=>(0,r.createElement)(e,t)),...Array.isArray(u)?u:[u]]));return n.displayName=`${e}`,n}},9865:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("BookOpen",[["path",{d:"M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z",key:"vv98re"}],["path",{d:"M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",key:"1cyq3y"}]])},2442:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]])},3523:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]])},9089:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("Cookie",[["path",{d:"M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5",key:"laymnq"}],["path",{d:"M8.5 8.5v.01",key:"ue8clq"}],["path",{d:"M16 15.5v.01",key:"14dtrp"}],["path",{d:"M12 12v.01",key:"u5ubse"}],["path",{d:"M11 17v.01",key:"1hyl5a"}],["path",{d:"M7 14v.01",key:"uct60s"}]])},9168:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("Crown",[["path",{d:"m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14",key:"zkxr6b"}]])},8956:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]])},5883:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},8004:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},9409:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},9036:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("Shield",[["path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10",key:"1irkt0"}]])},8957:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]])},7972:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},2549:function(e,t,n){"use strict";n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(2898).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},6435:function(e,t,n){"use strict";n.d(t,{f:function(){return o}});var r=n(2265);let a=["light","dark"],l="(prefers-color-scheme: dark)",i="undefined"==typeof window,s=(0,r.createContext)(void 0),o=e=>(0,r.useContext)(s)?r.createElement(r.Fragment,null,e.children):r.createElement(u,e),c=["light","dark"],u=({forcedTheme:e,disableTransitionOnChange:t=!1,enableSystem:n=!0,enableColorScheme:i=!0,storageKey:o="theme",themes:u=c,defaultTheme:p=n?"system":"light",attribute:y="data-theme",value:k,children:v,nonce:g})=>{let[w,E]=(0,r.useState)(()=>m(o,p)),[b,$]=(0,r.useState)(()=>m(o)),x=k?Object.values(k):u,C=(0,r.useCallback)(e=>{let r=e;if(!r)return;"system"===e&&n&&(r=h());let l=k?k[r]:r,s=t?f():null,o=document.documentElement;if("class"===y?(o.classList.remove(...x),l&&o.classList.add(l)):l?o.setAttribute(y,l):o.removeAttribute(y),i){let e=a.includes(p)?p:null,t=a.includes(r)?r:e;o.style.colorScheme=t}null==s||s()},[]),M=(0,r.useCallback)(e=>{E(e);try{localStorage.setItem(o,e)}catch(e){}},[e]),Z=(0,r.useCallback)(t=>{$(h(t)),"system"===w&&n&&!e&&C("system")},[w,e]);(0,r.useEffect)(()=>{let e=window.matchMedia(l);return e.addListener(Z),Z(e),()=>e.removeListener(Z)},[Z]),(0,r.useEffect)(()=>{let e=e=>{e.key===o&&M(e.newValue||p)};return window.addEventListener("storage",e),()=>window.removeEventListener("storage",e)},[M]),(0,r.useEffect)(()=>{C(null!=e?e:w)},[e,w]);let S=(0,r.useMemo)(()=>({theme:w,setTheme:M,forcedTheme:e,resolvedTheme:"system"===w?b:w,themes:n?[...u,"system"]:u,systemTheme:n?b:void 0}),[w,M,e,b,n,u]);return r.createElement(s.Provider,{value:S},r.createElement(d,{forcedTheme:e,disableTransitionOnChange:t,enableSystem:n,enableColorScheme:i,storageKey:o,themes:u,defaultTheme:p,attribute:y,value:k,children:v,attrs:x,nonce:g}),v)},d=(0,r.memo)(({forcedTheme:e,storageKey:t,attribute:n,enableSystem:i,enableColorScheme:s,defaultTheme:o,value:c,attrs:u,nonce:d})=>{let m="system"===o,f="class"===n?`var d=document.documentElement,c=d.classList;c.remove(${u.map(e=>`'${e}'`).join(",")});`:`var d=document.documentElement,n='${n}',s='setAttribute';`,h=s?a.includes(o)&&o?`if(e==='light'||e==='dark'||!e)d.style.colorScheme=e||'${o}'`:"if(e==='light'||e==='dark')d.style.colorScheme=e":"",p=(e,t=!1,r=!0)=>{let l=c?c[e]:e,i=t?e+"|| ''":`'${l}'`,o="";return s&&r&&!t&&a.includes(e)&&(o+=`d.style.colorScheme = '${e}';`),"class"===n?o+=t||l?`c.add(${i})`:"null":l&&(o+=`d[s](n,${i})`),o},y=e?`!function(){${f}${p(e)}}()`:i?`!function(){try{${f}var e=localStorage.getItem('${t}');if('system'===e||(!e&&${m})){var t='${l}',m=window.matchMedia(t);if(m.media!==t||m.matches){${p("dark")}}else{${p("light")}}}else if(e){${c?`var x=${JSON.stringify(c)};`:""}${p(c?"x[e]":"e",!0)}}${m?"":"else{"+p(o,!1,!1)+"}"}${h}}catch(e){}}()`:`!function(){try{${f}var e=localStorage.getItem('${t}');if(e){${c?`var x=${JSON.stringify(c)};`:""}${p(c?"x[e]":"e",!0)}}else{${p(o,!1,!1)};}${h}}catch(t){}}();`;return r.createElement("script",{nonce:d,dangerouslySetInnerHTML:{__html:y}})},()=>!0),m=(e,t)=>{let n;if(!i){try{n=localStorage.getItem(e)||void 0}catch(e){}return n||t}},f=()=>{let e=document.createElement("style");return e.appendChild(document.createTextNode("*{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}")),document.head.appendChild(e),()=>{window.getComputedStyle(document.body),setTimeout(()=>{document.head.removeChild(e)},1)}},h=e=>(e||(e=window.matchMedia(l)),e.matches?"dark":"light")},3649:function(e){e.exports={style:{fontFamily:"'__Inter_f367f3', '__Inter_Fallback_f367f3'",fontStyle:"normal"},className:"__className_f367f3"}},2167:function(e,t,n){"use strict";n.d(t,{M:function(){return y}});var r=n(2265),a=n(538);function l(){let e=(0,r.useRef)(!1);return(0,a.L)(()=>(e.current=!0,()=>{e.current=!1}),[]),e}var i=n(2363),s=n(8243),o=n(961);class c extends r.Component{getSnapshotBeforeUpdate(e){let t=this.props.childRef.current;if(t&&e.isPresent&&!this.props.isPresent){let e=this.props.sizeRef.current;e.height=t.offsetHeight||0,e.width=t.offsetWidth||0,e.top=t.offsetTop,e.left=t.offsetLeft}return null}componentDidUpdate(){}render(){return this.props.children}}function u({children:e,isPresent:t}){let n=(0,r.useId)(),a=(0,r.useRef)(null),l=(0,r.useRef)({width:0,height:0,top:0,left:0});return(0,r.useInsertionEffect)(()=>{let{width:e,height:r,top:i,left:s}=l.current;if(t||!a.current||!e||!r)return;a.current.dataset.motionPopId=n;let o=document.createElement("style");return document.head.appendChild(o),o.sheet&&o.sheet.insertRule(`
          [data-motion-pop-id="${n}"] {
            position: absolute !important;
            width: ${e}px !important;
            height: ${r}px !important;
            top: ${i}px !important;
            left: ${s}px !important;
          }
        `),()=>{document.head.removeChild(o)}},[t]),r.createElement(c,{isPresent:t,childRef:a,sizeRef:l},r.cloneElement(e,{ref:a}))}let d=({children:e,initial:t,isPresent:n,onExitComplete:a,custom:l,presenceAffectsLayout:i,mode:c})=>{let d=(0,o.h)(m),f=(0,r.useId)(),h=(0,r.useMemo)(()=>({id:f,initial:t,isPresent:n,custom:l,onExitComplete:e=>{for(let t of(d.set(e,!0),d.values()))if(!t)return;a&&a()},register:e=>(d.set(e,!1),()=>d.delete(e))}),i?void 0:[n]);return(0,r.useMemo)(()=>{d.forEach((e,t)=>d.set(t,!1))},[n]),r.useEffect(()=>{n||d.size||!a||a()},[n]),"popLayout"===c&&(e=r.createElement(u,{isPresent:n},e)),r.createElement(s.O.Provider,{value:h},e)};function m(){return new Map}var f=n(781),h=n(6567);let p=e=>e.key||"",y=({children:e,custom:t,initial:n=!0,onExitComplete:s,exitBeforeEnter:o,presenceAffectsLayout:c=!0,mode:u="sync"})=>{var m;(0,h.k)(!o,"Replace exitBeforeEnter with mode='wait'");let y=(0,r.useContext)(f.p).forceRender||function(){let e=l(),[t,n]=(0,r.useState)(0),a=(0,r.useCallback)(()=>{e.current&&n(t+1)},[t]);return[(0,r.useCallback)(()=>i.Wi.postRender(a),[a]),t]}()[0],k=l(),v=function(e){let t=[];return r.Children.forEach(e,e=>{(0,r.isValidElement)(e)&&t.push(e)}),t}(e),g=v,w=(0,r.useRef)(new Map).current,E=(0,r.useRef)(g),b=(0,r.useRef)(new Map).current,$=(0,r.useRef)(!0);if((0,a.L)(()=>{$.current=!1,function(e,t){e.forEach(e=>{let n=p(e);t.set(n,e)})}(v,b),E.current=g}),m=()=>{$.current=!0,b.clear(),w.clear()},(0,r.useEffect)(()=>()=>m(),[]),$.current)return r.createElement(r.Fragment,null,g.map(e=>r.createElement(d,{key:p(e),isPresent:!0,initial:!!n&&void 0,presenceAffectsLayout:c,mode:u},e)));g=[...g];let x=E.current.map(p),C=v.map(p),M=x.length;for(let e=0;e<M;e++){let t=x[e];-1!==C.indexOf(t)||w.has(t)||w.set(t,void 0)}return"wait"===u&&w.size&&(g=[]),w.forEach((e,n)=>{if(-1!==C.indexOf(n))return;let a=b.get(n);if(!a)return;let l=x.indexOf(n),i=e;i||(i=r.createElement(d,{key:p(a),isPresent:!1,onExitComplete:()=>{w.delete(n);let e=Array.from(b.keys()).filter(e=>!C.includes(e));if(e.forEach(e=>b.delete(e)),E.current=v.filter(t=>{let r=p(t);return r===n||e.includes(r)}),!w.size){if(!1===k.current)return;y(),s&&s()}},custom:t,presenceAffectsLayout:c,mode:u},a),w.set(n,i)),g.splice(l,0,i)}),g=g.map(e=>{let t=e.key;return w.has(t)?e:r.createElement(d,{key:p(e),isPresent:!0,presenceAffectsLayout:c,mode:u},e)}),r.createElement(r.Fragment,null,w.size?g:g.map(e=>(0,r.cloneElement)(e)))}}}]);