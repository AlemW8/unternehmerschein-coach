import UniversalFlashcards from '@/components/universal-flashcards'

export default function KalkulationFlashcards() {
  return (
    <UniversalFlashcards 
      category="kalkulation"
      title="Kalkulation"
      colorScheme="yellow"
    />
  )
}