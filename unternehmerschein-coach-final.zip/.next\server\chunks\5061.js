"use strict";exports.id=5061,exports.ids=[5061],exports.modules={55061:(e,t,r)=>{r.d(t,{Pi:()=>s,Ui:()=>d,bn:()=>g});var n=r(61584),l=r.n(n);let i=process.env.SENDGRID_API_KEY;i?l().setApiKey(i):console.warn("⚠️ SENDGRID_API_KEY fehlt in .env.local");let o=process.env.SENDGRID_FROM_EMAIL||"aleemwaqar@outlook.com",a=process.env.SENDGRID_FROM_NAME||"FahrGewerbe Team";async function s(e,t,r,n,i){try{let s={to:e,from:{email:o,name:a},subject:"\uD83C\uDF89 Willkommen bei FahrGewerbe!",html:`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willkommen bei FahrGewerbe</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f3f4f6;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f3f4f6; padding: 40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #2563eb 0%, #4f46e5 100%); padding: 40px; text-align: center; border-radius: 8px 8px 0 0;">
              <h1 style="color: #ffffff; margin: 0; font-size: 32px; font-weight: bold;">🎉 Willkommen!</h1>
              <p style="color: #e0e7ff; margin: 10px 0 0 0; font-size: 18px;">Dein FahrGewerbe Account ist bereit</p>
            </td>
          </tr>

          <!-- Content -->
          <tr>
            <td style="padding: 40px;">
              <p style="color: #374151; font-size: 16px; line-height: 24px; margin: 0 0 20px 0;">
                Hallo <strong>${t}</strong>,
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 24px; margin: 0 0 30px 0;">
                vielen Dank f\xfcr deine Zahlung! Dein Account wurde erfolgreich erstellt. 
                Hier sind deine Login-Daten:
              </p>

              <!-- Login Box -->
              <div style="background-color: #f9fafb; border-left: 4px solid #2563eb; padding: 20px; margin: 0 0 30px 0; border-radius: 4px;">
                <p style="margin: 0 0 10px 0; color: #6b7280; font-size: 14px; font-weight: bold; text-transform: uppercase;">
                  Deine Login-Daten:
                </p>
                <p style="margin: 0 0 8px 0; color: #111827; font-size: 16px;">
                  <strong>Email:</strong> ${e}
                </p>
                <p style="margin: 0; color: #111827; font-size: 16px;">
                  <strong>Passwort:</strong> <code style="background-color: #e5e7eb; padding: 4px 8px; border-radius: 4px; font-family: monospace;">${r}</code>
                </p>
              </div>

              <!-- Plan Info -->
              <div style="background-color: #ecfdf5; border: 1px solid #10b981; padding: 20px; margin: 0 0 30px 0; border-radius: 4px;">
                <p style="margin: 0 0 8px 0; color: #065f46; font-size: 14px; font-weight: bold;">
                  📦 Dein Plan:
                </p>
                <p style="margin: 0; color: #047857; font-size: 16px;">
                  <strong>${n}</strong> - ${i}
                </p>
              </div>

              <!-- CTA Button -->
              <div style="text-align: center; margin: 40px 0;">
                <a href="http://localhost:3000/auth/signin" 
                   style="display: inline-block; background-color: #2563eb; color: #ffffff; text-decoration: none; padding: 16px 32px; border-radius: 8px; font-weight: bold; font-size: 16px;">
                  Jetzt einloggen →
                </a>
              </div>

              <!-- Features -->
              <div style="margin: 30px 0;">
                <p style="color: #374151; font-size: 16px; font-weight: bold; margin: 0 0 15px 0;">
                  Was dich erwartet:
                </p>
                <ul style="color: #6b7280; font-size: 15px; line-height: 24px; margin: 0; padding-left: 20px;">
                  <li style="margin-bottom: 8px;">✅ Alle 255 Pr\xfcfungsfragen</li>
                  <li style="margin-bottom: 8px;">✅ Flashcards & Multiple-Choice</li>
                  <li style="margin-bottom: 8px;">✅ Fortschritt-Tracking</li>
                  <li style="margin-bottom: 8px;">✅ Pr\xfcfungssimulation</li>
                  <li>✅ Offline-Zugriff (PWA)</li>
                </ul>
              </div>

              <!-- Support -->
              <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 30px 0 0 0; border-radius: 4px;">
                <p style="margin: 0; color: #92400e; font-size: 14px;">
                  <strong>💡 Tipp:</strong> \xc4ndere dein Passwort nach dem ersten Login in deinem Profil.
                </p>
              </div>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color: #f9fafb; padding: 30px; text-align: center; border-radius: 0 0 8px 8px; border-top: 1px solid #e5e7eb;">
              <p style="margin: 0 0 10px 0; color: #6b7280; font-size: 14px;">
                Fragen? Kontaktiere uns: <a href="mailto:${o}" style="color: #2563eb; text-decoration: none;">${o}</a>
              </p>
              <p style="margin: 0; color: #9ca3af; font-size: 12px;">
                \xa9 ${new Date().getFullYear()} FahrGewerbe. Alle Rechte vorbehalten.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `,text:`
Willkommen bei FahrGewerbe!

Hallo ${t},

vielen Dank f\xfcr deine Zahlung! Dein Account wurde erfolgreich erstellt.

DEINE LOGIN-DATEN:
Email: ${e}
Passwort: ${r}

DEIN PLAN:
${n} - ${i}

Jetzt einloggen: http://localhost:3000/auth/signin

Was dich erwartet:
✅ Alle 255 Pr\xfcfungsfragen
✅ Flashcards & Multiple-Choice
✅ Fortschritt-Tracking
✅ Pr\xfcfungssimulation
✅ Offline-Zugriff (PWA)

Tipp: \xc4ndere dein Passwort nach dem ersten Login in deinem Profil.

Fragen? Kontaktiere uns: ${o}

\xa9 ${new Date().getFullYear()} FahrGewerbe. Alle Rechte vorbehalten.
  `};return await l().send(s),console.log(`✅ Welcome Email gesendet an: ${e}`),{success:!0}}catch(e){return console.error("❌ SendGrid Email Error:",e),{success:!1,error:e}}}async function d(e,t,r,n,i){try{let s={to:e,from:{email:o,name:a},subject:1===r?"⚠️ Zahlung fehlgeschlagen - Bitte Zahlungsmethode aktualisieren":2===r?"\uD83D\uDEA8 2. Mahnung - Zahlung fehlgeschlagen":"\uD83D\uDD34 Letzte Mahnung - Account wird gesperrt",html:`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Zahlung fehlgeschlagen</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f3f4f6;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f3f4f6; padding: 40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
          
          <tr>
            <td style="background-color: ${1===r?"#f59e0b":2===r?"#ef4444":"#dc2626"}; padding: 40px; text-align: center; border-radius: 8px 8px 0 0;">
              <h1 style="color: #ffffff; margin: 0; font-size: 28px; font-weight: bold;">⚠️ Zahlung fehlgeschlagen</h1>
            </td>
          </tr>

          <tr>
            <td style="padding: 40px;">
              <p style="color: #374151; font-size: 16px; line-height: 24px; margin: 0 0 20px 0;">
                Hallo <strong>${t}</strong>,
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 24px; margin: 0 0 30px 0;">
                ${1===r?"Deine letzte Zahlung ist fehlgeschlagen.":2===r?"Dies ist die 2. Mahnung. Bitte handle jetzt!":"LETZTE MAHNUNG! Dein Account wird in K\xfcrze gesperrt."}
              </p>

              <div style="background-color: #fef2f2; border-left: 4px solid #ef4444; padding: 20px; margin: 0 0 30px 0; border-radius: 4px;">
                <p style="margin: 0 0 10px 0; color: #991b1b; font-size: 16px; font-weight: bold;">
                  Account-Status:
                </p>
                <p style="margin: 0; color: #dc2626; font-size: 16px;">
                  Dein Account wird in <strong>${n} Tagen</strong> gesperrt, wenn die Zahlung nicht erfolgt.
                </p>
              </div>

              <div style="text-align: center; margin: 40px 0;">
                <a href="${i}" 
                   style="display: inline-block; background-color: #dc2626; color: #ffffff; text-decoration: none; padding: 16px 32px; border-radius: 8px; font-weight: bold; font-size: 16px;">
                  Zahlungsmethode aktualisieren →
                </a>
              </div>

              <p style="color: #6b7280; font-size: 14px; line-height: 20px; margin: 30px 0 0 0;">
                Wenn du bereits gezahlt hast, kannst du diese Email ignorieren.
              </p>
            </td>
          </tr>

          <tr>
            <td style="background-color: #f9fafb; padding: 30px; text-align: center; border-radius: 0 0 8px 8px; border-top: 1px solid #e5e7eb;">
              <p style="margin: 0; color: #6b7280; font-size: 14px;">
                Support: <a href="mailto:${o}" style="color: #2563eb;">${o}</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `,text:`
Zahlung fehlgeschlagen - Mahnung ${r}

Hallo ${t},

deine letzte Zahlung ist fehlgeschlagen.

Account-Status: Wird in ${n} Tagen gesperrt, wenn die Zahlung nicht erfolgt.

Zahlungsmethode aktualisieren:
${i}

Support: ${o}
  `};return await l().send(s),console.log(`✅ Payment Failed Email gesendet an: ${e}`),{success:!0}}catch(e){return console.error("❌ SendGrid Email Error:",e),{success:!1,error:e}}}async function g(e,t,r,n){try{let i={to:e,from:{email:o,name:a},subject:"✅ Bestellbest\xe4tigung - FahrGewerbe Premium",html:`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bestellbest\xe4tigung</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f3f4f6;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f3f4f6; padding: 40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 40px; text-align: center; border-radius: 8px 8px 0 0;">
              <h1 style="color: #ffffff; margin: 0; font-size: 32px; font-weight: bold;">✅ Bestellung best\xe4tigt!</h1>
              <p style="color: #d1fae5; margin: 10px 0 0 0; font-size: 18px;">Vielen Dank f\xfcr deinen Kauf</p>
            </td>
          </tr>

          <!-- Content -->
          <tr>
            <td style="padding: 40px;">
              <p style="color: #374151; font-size: 16px; line-height: 24px; margin: 0 0 20px 0;">
                Hallo <strong>${t}</strong>,
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 24px; margin: 0 0 30px 0;">
                deine Zahlung wurde erfolgreich verarbeitet! 🎉
              </p>

              <!-- Order Details -->
              <div style="background-color: #f0fdf4; border: 2px solid #10b981; padding: 20px; margin: 0 0 30px 0; border-radius: 8px;">
                <h3 style="margin: 0 0 15px 0; color: #065f46; font-size: 18px; font-weight: bold;">
                  📦 Bestelldetails
                </h3>
                <table width="100%" cellpadding="8" cellspacing="0" style="border-collapse: collapse;">
                  <tr>
                    <td style="color: #047857; font-size: 15px; border-bottom: 1px solid #86efac; padding: 8px 0;">
                      Produkt:
                    </td>
                    <td style="color: #065f46; font-size: 15px; font-weight: bold; border-bottom: 1px solid #86efac; padding: 8px 0; text-align: right;">
                      ${r}
                    </td>
                  </tr>
                  <tr>
                    <td style="color: #047857; font-size: 15px; padding: 8px 0;">
                      Betrag:
                    </td>
                    <td style="color: #065f46; font-size: 15px; font-weight: bold; padding: 8px 0; text-align: right;">
                      ${n}
                    </td>
                  </tr>
                  <tr>
                    <td style="color: #047857; font-size: 15px; padding: 8px 0;">
                      Datum:
                    </td>
                    <td style="color: #065f46; font-size: 15px; font-weight: bold; padding: 8px 0; text-align: right;">
                      ${new Date().toLocaleDateString("de-DE")}
                    </td>
                  </tr>
                </table>
              </div>

              <!-- Next Steps -->
              <div style="background-color: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; margin: 0 0 30px 0; border-radius: 4px;">
                <h3 style="margin: 0 0 15px 0; color: #1e40af; font-size: 18px; font-weight: bold;">
                  📝 N\xe4chste Schritte:
                </h3>
                <ol style="color: #1e3a8a; font-size: 15px; line-height: 24px; margin: 0; padding-left: 20px;">
                  <li style="margin-bottom: 10px;">
                    <strong>Account erstellen:</strong> Lege deine Login-Daten fest (Email wurde bereits ge\xf6ffnet)
                  </li>
                  <li style="margin-bottom: 10px;">
                    <strong>Anmelden:</strong> Nutze deine Email und dein gew\xe4hltes Passwort
                  </li>
                  <li>
                    <strong>Loslegen:</strong> Starte mit allen 255 Pr\xfcfungsfragen!
                  </li>
                </ol>
              </div>

              <!-- Features -->
              <div style="margin: 30px 0;">
                <h3 style="color: #374151; font-size: 18px; font-weight: bold; margin: 0 0 15px 0;">
                  Was dich erwartet:
                </h3>
                <ul style="color: #6b7280; font-size: 15px; line-height: 24px; margin: 0; padding-left: 20px;">
                  <li style="margin-bottom: 8px;">✅ Alle 255 Pr\xfcfungsfragen</li>
                  <li style="margin-bottom: 8px;">✅ Flashcards & Multiple-Choice</li>
                  <li style="margin-bottom: 8px;">✅ Pr\xfcfungssimulator</li>
                  <li style="margin-bottom: 8px;">✅ Fortschrittstracking</li>
                  <li style="margin-bottom: 8px;">✅ Mobile App (iOS & Android)</li>
                  <li>✅ Offline-Zugriff (PWA)</li>
                </ul>
              </div>

              <!-- Support -->
              <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 30px 0 0 0; border-radius: 4px;">
                <p style="margin: 0; color: #92400e; font-size: 14px;">
                  <strong>💡 Fragen?</strong> Unser Support-Team hilft dir gerne weiter!
                </p>
              </div>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color: #f9fafb; padding: 30px; text-align: center; border-radius: 0 0 8px 8px; border-top: 1px solid #e5e7eb;">
              <p style="margin: 0 0 10px 0; color: #6b7280; font-size: 14px;">
                Support: <a href="mailto:${o}" style="color: #2563eb; text-decoration: none;">${o}</a>
              </p>
              <p style="margin: 0; color: #9ca3af; font-size: 12px;">
                \xa9 ${new Date().getFullYear()} FahrGewerbe. Alle Rechte vorbehalten.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `,text:`
Bestellbest\xe4tigung - FahrGewerbe

Hallo ${t},

deine Zahlung wurde erfolgreich verarbeitet! 🎉

BESTELLDETAILS:
Produkt: ${r}
Betrag: ${n}
Datum: ${new Date().toLocaleDateString("de-DE")}

N\xc4CHSTE SCHRITTE:
1. Account erstellen: Lege deine Login-Daten fest
2. Anmelden: Nutze deine Email und dein Passwort
3. Loslegen: Starte mit allen 255 Pr\xfcfungsfragen!

Was dich erwartet:
✅ Alle 255 Pr\xfcfungsfragen
✅ Flashcards & Multiple-Choice
✅ Pr\xfcfungssimulator
✅ Fortschrittstracking
✅ Mobile App (iOS & Android)
✅ Offline-Zugriff (PWA)

Fragen? Kontaktiere uns: ${o}

\xa9 ${new Date().getFullYear()} FahrGewerbe. Alle Rechte vorbehalten.
  `};return await l().send(i),console.log(`✅ Bestellbest\xe4tigung gesendet an: ${e}`),{success:!0}}catch(e){return console.error("❌ SendGrid Email Error:",e),{success:!1,error:e}}}}};