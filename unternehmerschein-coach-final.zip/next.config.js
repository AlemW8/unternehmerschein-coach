/** @type {import('next').NextConfig} */
const nextConfig = {
  // SERVER-MODUS: Vollständige Next.js App mit Stripe & Login
  // output: 'export', // DEAKTIVIERT für Server-Features
  trailingSlash: true,
  experimental: {
    serverComponentsExternalPackages: ['bcryptjs']
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  // Performance Optimierung  
  poweredByHeader: false,
  compress: true,
  // API Configuration für Stripe & Auth
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Credentials', value: 'true' },
          { key: 'Access-Control-Allow-Origin', value: '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET,POST,PUT,DELETE,OPTIONS' },
          { key: 'Access-Control-Allow-Headers', value: 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization' },
        ],
      },
    ]
  },
}

module.exports = nextConfig
