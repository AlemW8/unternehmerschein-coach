# Vercel Deployment Setup

## Environment Variables für Vercel

### 1. Stripe Konfiguration
```
STRIPE_SECRET_KEY=sk_test_51QCvAm6zHGhSUEk1sxtBJWJGqWmRJzr8Y1u9FNQoXeEZJzTJz4lT5sXwX2rCzY8T9sLz4V6Y3oK0mM9wN7eR5pQ3uG1
STRIPE_PUBLISHABLE_KEY=pk_test_51QCvAm6zHGhSUEk1NXYoT2FWwzNp8K5L7mR3pQ1sX9V0wN4eT6uG2hM7jY8sN9pL4tK3vB2zS1xF5wH8rE6qU0yT
STRIPE_WEBHOOK_SECRET=whsec_1234567890abcdef...
```

### 2. NextAuth Konfiguration  
```
NEXTAUTH_SECRET=unternehmerschein-coach-super-secret-key-2024-production-version-secure
NEXTAUTH_URL=https://unternehmerschein-coach.vercel.app
```

### 3. App Konfiguration
```
NODE_ENV=production
NEXT_PUBLIC_APP_URL=https://unternehmerschein-coach.vercel.app
```

### 4. Bereits konfigurierte Stripe Price IDs
```
NEXT_PUBLIC_STRIPE_MONTHLY_PRICE_ID=price_1SDjLt6zHGhSUEk1en6wrm1q
NEXT_PUBLIC_STRIPE_YEARLY_PRICE_ID=price_1SDjMn6zHGhSUEk1C2Bt8pWx
```

## Deployment Schritte

1. **GitHub Upload**: ZIP-Datei `unternehmerschein-coach-github.zip` hochladen
2. **Vercel Connect**: Repository mit Vercel verbinden
3. **Environment Variables**: Alle oben genannten Variablen in Vercel hinzufügen
4. **Deploy**: Automatisches Deployment startet

## Features enthalten
- ✅ Stripe Integration (Monatlich €29.99, Jährlich €199.99)
- ✅ User Authentication System
- ✅ Vollständige DSGVO-Compliance (Impressum, Datenschutz, AGB, Widerrufsrecht)
- ✅ Cookie Consent Management
- ✅ Responsive Design mit Dark Mode
- ✅ Alle Lernmodule und Prüfungssimulationen

## Nächste Schritte nach Deployment
1. Stripe Webhook URLs in Stripe Dashboard konfigurieren
2. DNS Records für Custom Domain (optional)
3. Live Testing aller Payment Flows
